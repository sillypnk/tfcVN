

# So, the new way to script conversations! 

# As you can see, it will accept the old AND new formats, there are some points where you will have to use the old format, 
# like using variables in code, or giving images a scale parameter. 

# (you can mix and match as much as you want)

default mc_kesash_chat_var = "can use this format"

default mc_kesash_initial = kps_build_conversation_list("""
kesash: This is purely a code demo for the new custom scripting language
kesash: Which... obviously... you can't see from using the phone....
kesash: Its in test_char_4.
kesash           :                 From the pov of playing the game you wont see much difference in what's happening
{"kesash"    :   "But if you look at how this conversation is created, you will, like how white space doesnt matter around the : "}
code:kps_send_message_to_phone(mc_kesash_conversation, 'kesash', 'Or how all these were sent a different way')
{"code":"kps_send_message_to_phone(mc_kesash_conversation, 'kesash', 'This one too....')"}
code:'''if True:
    kps_send_message_to_phone(mc_kesash_conversation, 'kesash', 'And this one (kind of)')
else:
    kps_send_message_to_phone(mc_kesash_conversation, 'kesash', 'This will never send :c')
'''

{"kesash":f"If you want to use variables you {mc_kesash_chat_var}"}
kesash: but {mc_kesash_chat_var} will not work, it needs to be in the format above
kesash: Or f string the entire thing, but I cant do that here, because im accessing dicts mid conversation at some points. 

mc:Oh, cool
kesash: And we can reply to messages now
mc:What do you mean?
{"kesash":"Like this", "reply":"What do you mean?"}
{"mc":"Oh thats cool", "reply":"Like this"}
kesash: AND the background setting has been replaces with Themes instead, which changes all the colours on the phone
"""
)


default mc_kesash_conversation = kps_build_conversation(mc_kesash_initial, kps_member("mc"), kps_member("kesash", profile = "kesash/kesash_profile.png"))



# Because you will never have access to Kesash's (my) phone, I dont need to create it. Mc phone is already defined. This is all thats needed


