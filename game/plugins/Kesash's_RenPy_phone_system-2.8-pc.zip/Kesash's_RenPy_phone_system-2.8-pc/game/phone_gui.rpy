# Gui for the phones

## 99% of this is just a standard renpy gui for showing a button on the screen. Click the button, the phone opens. 

## Phone is opened with kps_open_phone(which_phone)

#### FEEL FREE TO JUST COPY AND PASTE IT, JUST SWAP THE IMAGES AND POSITIONS TO WHAT YOU WANT.



init python:
    def check_phone_alert(phone_data):
        # phone_messages_registry is where every conversation is stored, automatically.
        for item in phone_messages_registry:
            # So we check every convo, see if this phone is a member of any
            if phone_data["name"] in item["members"].keys():
                # If they are we check if its been completed
                if len(item['current_dialogue']) > kps_get_conversation_index(item):
                    # Find any uncompleted chats? Show the notification
                    return True


screen phone_icon_overlay: 
    zorder 200
    if mc_phone_show:
        imagebutton:
            idle "gui/phone_small.png"
            hover "gui/phone_small_hover.png"
            action [
                Hide("phone_icon_overlay"),
                Function(kps_open_phone, mc_phone),
                ]
            xalign 0.99
            yalign 0.01
            at Transform(size=(154, 230))


    # Just hides the phone at the start of the game
    if sarah_phone_show:
        imagebutton:
            idle "gui/sarah_phone_small.png"
            hover "gui/sarah_phone_small_hover.png"
            action [
                Hide("phone_icon_overlay"),
                # only differences here are that we are updating phone_data with sarah_phone not MC phone, so it opens hers.
                # None of this needs to be done in a screen. You can just set it manually and call phone_home. Will still work.
                Function(kps_open_phone, sarah_phone),
                # and then disabling click to send for this phone (well technically were disabling it globally...)
                # Note that if this is set to true it will overwrite the disable messaging for when they are talking
                # So you will be able to click to send their messages, but any sent by anyone else will never be sent
                Function(lambda: setattr(store, "click_to_send", False)),
                Show("phone_home")
                ]
            xalign 0.95
            yalign 0.01
            at Transform(size=(154, 230))


#### CURRENTLY BROKE, IGNORE #####
    if check_phone_alert(mc_phone) and mc_phone_show:
        add "gui/unread.png" xpos 0.95 ypos 0.06 at Transform(anchor=(0.5, 0.0), size=(100, 100))
    if check_phone_alert(sarah_phone) and sarah_phone_show:
        add "gui/unread.png" xpos 0.915 ypos 0.06 at Transform(anchor=(0.5, 0.0), size=(100, 100))
    if check_phone_alert(iris_phone) and iris_phone_show:
        add "gui/unread.png" xpos 0.875 ypos 0.06 at Transform(anchor=(0.5, 0.0), size=(100, 100))


# Just here to show the variable change while the phone is opened
screen money_display:
    frame:
        xalign 0.0
        yalign 0.0
        padding (10, 10)
        vbox:
            spacing 5
            text "Money: [money]"
            hbox:
                spacing 5
                textbutton "-100" action SetVariable("money", money - 100)
                textbutton "+100" action SetVariable("money", money + 100)


label hide_all_gui:
    hide screen phone_icon_overlay
    $ renpy.hide_screen("phone_icon_overlay")
    $ renpy.restart_interaction()
    return 

label show_all_gui:
    show screen phone_icon_overlay
    show screen money_display
    $ renpy.restart_interaction()
    return 