

# So, by here you will have already seen the two different ways of creating conversations. Because im doing some fun things like 
# dynamically creating choices at the end of the first conversation, I opted to use the old system here. Its the only way to modify 
# a conversation your currently in while running code that comes from a var..... But this is something you never HAVE to do

default sarah_choices = []

# Code can be multi line, and doesnt need to be coded in the middle of the list,
# You can create it outside the list, set it to a var, and just pass that var in!

# First im clearing the list with "code":"""del sarah_choices[:]
# Then im checking if the index of each list is < 2, if it is then it hasnt been read yet (see note after this conversation thread)
# This entire block of code could just be inside the conversation, instead of defined here and passed in as a variable
# But as messages are sent at a speed that is decided off their length..... Well, you would be waiting a while for this to send!


default sarah_starting_dialogue_conversation_populator = """del sarah_choices[:]
if kps_get_conversation_index(types_of_messages_chat) < 2:
    sarah_choices.append(["Types of messages", "types_of_messages_chat"]) 
if kps_get_conversation_index(group_chats_chat) < 2:
    sarah_choices.append(["Group chats", "group_chats_chat"])
if kps_get_conversation_index(multiple_phones_chat) < 2:
    sarah_choices.append(["Multiple phones", "multiple_phones_chat"])
if kps_get_conversation_index(explain_lable_safe_chat) < 2:
    sarah_choices.append(["Explain label safe", "explain_lable_safe_chat"])
if sarah_choices == []:
    sarah_choices.append(["Isnt that everything?", "after_choices_chat"])
sarah_starting_dialogue[-1] = sarah_choices
"""
# Then at the end I just set the last item in this list to the choices list I just made :)

# Im modifying this one during gameplay, so I create it with default and not define

default sarah_starting_dialogue = [
    {"sarah":"Hello!"},
    {"sarah":"This is the most complicated example of the 3 starting conversations, and is in test_char_3.rpy!"},
    {"sarah":"Nova has the simplest, Iris is in the middle."},
    {"sarah":"Once youve finished this one, close the phone, and you will go to a section for seeing some more features"},
    # RUN THAT BIG BLOCK OF CODE
    {"code":sarah_starting_dialogue_conversation_populator},    

    {"sarah":"So"},
    {"sarah":"What do you want to see?"},
    # This empty list is the one that gets populated with the options, once an option has been picked and you loop back
    # to the start, it wont be there anymore :D
    []
]
    

    # --- conversation indexes ---
    # In the conversation above, I dynamically build a list of choices based on how far the player has progressed in other conversations.
    # Each conversation has an associated index that tracks progress. The index name is always the conversation name with "_index_kps_" appended. 
    # The kps_get_conversation_index() function will get the index of the conversation list passed in

    # Every time a message is sent in a conversation, its index is incremented by 1.
    # Sooo you can check how far the player has progressed, or whether a conversation has been completed, or even started, 
    # by comparing the index to the length of the conversation list.

    # SO, I used these indexes to decide which options should appear.
    # If an index is below a certain value, that conversation hasnt been chosen yet, so its option is added to the choices list.
    # Once the index reaches the required point, that option is no longer shown.
    # ---------------------------------------------------------



    # The standard uses of keys here is explained in test_char_simple.rpy. Please read through that first. 
define types_of_messages_chat = [ 
    {"mc":"Types of messages!"},
    {"sarah":"Okay, there are five main types of messages"},
    {"sarah":"The first is... this... a normal chat message"},
    {"mc":"Okay"},
    {"sarah":"The second is a system message, they can say anything you want"},
    {"system":"You have been blocked"},
    {"system":"User has gone offline"},
    {"system":"Friday"},
    {"system":"Random system message"},
    {"sarah":"Lots of uses :)"},
    {"mc":"Cool!"},
    {"sarah":"The third isn't really a 'message', but a way to delete already sent messages"},
    {"sarah":"So pretend I sent a message and regretted it, I can delete it"},
    {"sarah":"For now i'll just delete this message, watch it"},
    {"sarah":"And it doesnt need to be done straight away, you can delete it 10 messages later if you want"},
    {"sarah":"Deleting it now!"},
    {"delete":"For now i'll just delete this message, watch it"},
    {"mc":"Oh, it's gone!"},
    {"sarah":"Then we have image messages"},
    {"image":"test/test_image.png"},
    {"sarah":"That image will have also been automatically unlocked in your phones gallery"},
    {"sarah":"And you can click it to make it full screen too"},
    {"mc":"Cool"},
    {"sarah":"Images can be deleted too"},
    {"image":"test/test_image_2.png"},
    {"sarah":"and now to delete it...."},
    {"delete":"test/test_image_2.png"},
    {"mc":"Okay"},
    {"sarah":"The last message type, is another that isn't really a message...."},
    {"sarah":"It will be invisible to any players, but its the most useful (and complicated) type!"},
    {"sarah":"Code messages!"},
    {"mc":"Code?"},
    {"sarah":"Yep, you can do anything from changing in game variables, to creating new chats, new phones, new contacts"},
    {"sarah":"So say at this point you wanted the character to recieve another message from another character"},
    {"sarah":"Or trigger a notification, or force close the phone, jump to a new label, anything"},
    {"sarah":"You can use a code message to acheieve it"},
    {"sarah":"There are lots of examples of this, you can see them after finishing this chat"},
    {"mc":"Anything else?"},
    {"sarah":"Yep, one of my favorite uses is conditional messages, so you can make it send different messages based on something"},
    {"sarah":"But without needing to create an entire new thread, so, for example, you want one single message to send differently based on a choice?"},
    {"sarah":"Its not worth creating an entire new thread, for one message, so you use a code block to send it on a condition"},
    # So... what are we doing here... check the comment after this chat list!
    {"code": """
if True:
    kps_send_message_to_phone(mc_sarah_conversation, 'sarah', 'This message was sent using a code block under a condition, its pretty seamless')
else:
    kps_send_message_to_phone(mc_sarah_conversation, 'sarah', 'And this message will never get shown :c')
"""},
    {"mc":"Okay"},
    {"sarah":"There's alot more you can do with code messages too, you could have a different message based on the time of day if your game has times"},
    {"sarah":"Or if you recieve a message asking where you are, the reply could be dynamic for your location when you reply if its a free roam game"},
    {"sarah":"Or even unload a conversation thread and load in a different one based on conditions, instead of a choice"},
    {"sarah":"you could even have different options show up for the user to click based on different variables, theres really no limit, depends on your coding skill :D"},
    {"sarah":"Thats how the choices at the start are dissapearing after you pick them and I loop! Once you've gone through them all something different will happen"},
    {"mc":"Thats cool"},
    {"sarah":"Ironically, i'm about to use one now to loop this conversation back to the starting choices!"},
    # All im doing here is loading the initial conversation thread back into the conversation
    # Because the index tracks where you got to, im setting it back to 4 as thats just before the code block runs to generate the choices
    # If i set it to 0, it would start the entire conversation thread again from the start
    {"code":"""kps_set_conversation_index(sarah_starting_dialogue, 4)
kps_update_conversation(mc_sarah_conversation, sarah_starting_dialogue)
    """}
    # Then I use the function kps_update_conversation() to set the conversation back the that initial conversation list
]



    # --- Modifying conversations directly ---
    # SO. This whole thing runs automatically, adds chats, swaps to new ones etc...
    # But that doesnt mean you cant do it yourself outside the phone :D 
    # mc_sarah_conversation is the dict we create (at the bottom of this page) for the conversation between MC and Sarah, its the persistant chat history
    # So you can scroll up later and its all still there. So what happens when we append to it? Well, that message just appears! 
    # The phone DOES NOT NEED TO BE OPEN to do this, you can do this mid label to have someone message, it will be there waiting when they open the phone. 
    # By doing this inside the phone we can do a few cool things though:
    #     Free roam game? Have the conditional check current location, reply to a message saying 'where are you' with where they actually are in game
    #     Do you have times in your game? Have the conversation automatically reference what time it is
    #     You could have messaging in this phone conversation trigger adding a message from another conversation entirely! Messaging Sarah? Get a text from Iris when you reach a certain point
    #     Saved a variable from a choice they made earlier? You can have the character reference that choice mid chat, without needing a seperate message thread. 
    #     ANYTHING ELSE YOU CAN THINK OF :D
    # ------------------------------------------------------


define group_chats_chat = [
    {"mc":"Group chats"},
    {"sarah":"SO! This one is a new feature!"},
    {"sarah":"When you define a conversation, you add 'members'"},
    {"sarah":"The second a conversation has more than 2 members it becomes a group chat"},
    {"sarah":"A few things change in a group chat"},
    {"mc":"Like what?"},
    {"sarah":"I think the easiest way is to show you!"},
    # Again, check the comment block at the end!
    {"code":"group_chat_conversation['members']['mc'] = {}"},
    {"code":"group_chat_conversation['members']['sarah'] = {'disable_messaging': True}"},
    {"sarah":"I just added you to a group chat, back out of this conversation and I can show you there"},
    {"sarah":"I also added myself so if you have my phone (ask about multiple phones) you will see it there too"},
    {"sarah":"Ill re loop this one back to the start"},
    {"code":"""kps_set_conversation_index(sarah_starting_dialogue, 4)
mc_sarah_conversation["current_index"] = 'sarah_starting_dialogue_index_kps_'
mc_sarah_conversation["current_dialogue"] = sarah_starting_dialogue
    """}
]

    # --- Modifying chat members dynamically ---
    # Like before we are modifying the dict we created to track a conversation. This time however we are modifying one that we are not currently in
    # The way the contact list on your phone is populated is the backend will automatically scan for all conversation dicts, and see if the owner of the current phone is a 'member' of any of them
    # The group chat dict and conversation have already been defined, but Sarah and the MC are currently not in the members list, so, the chat does not appear in their contacts.
    # By doing group_chat_conversation['members']['mc'] = {} we are adding the mc to the list of members (well, its a dict), and as soon as that has happened the group chat will instantly appear on that contact list
    # This doesnt only work for group chats. You can have a charcter say 'ill get x to message you now' then run 'chat_with_x_conversation['members']['mc']' = {}
    # and the contact x will appear on the phone, instantly. As long as the conversation dict has been defined, you can add and remove people from it whenever you want. Contacts will update accordingly. 
    # The second a chat has more than 2 members it automatically becomes a group chat (but be aware, group chats take a couple extra keys, so make sure they are set first, 
    # they are unused if the members = 2, so dont worry about setting them in advance)
    # --------------------------------------------------------
    
    # --- Disabling messaging from one pov ---
    # Were you wondering why we would set the mc's name to en empty dict when adding him as a member? Well, that dict is used.
    # For sarah we are running group_chat_conversation['members']['sarah'] = {'disable_messaging': True}"}, this is doing the exact same thing, adding her to the group chat, but it is also setting an extra condition.
    # The disable messaging key value decides if, while holding that persons phone, will this chat pause. If True, then NOTHING will happen in the chat from that persons POV.
    # This is true for both group and 1 on 1 chats. So, if you open the group chat using Sarah's phone, no messages will send. Ever. 
    # But the second you swap back to the mc's phone the chat will continue. 
    #
    # You dont have to just use this when adding a member, or making it perminenet. You could, at a point in a conversation, set this value for the one you are in, For all members, and keep it like that until a condition has been met
    # Like reaching another point in a conversation with someone else, then settling it back to False, re-enabling messaging. 
    # Use it to force pause any conversation for any reason, whenever you want. Unpause and everything will continue from where it was. 
    # ------------------------------------------------------


define multiple_phones_chat = [
    {"mc":"Multiple phones"},
    {"sarah":"YES, this one I like"},
    {"sarah":"So you can have as many phones as youd like!"},
    {"sarah":"All are completely independant, and, as soon as you create a conversation"},
    {"sarah":"And add the person to the 'members' list"},
    {"sarah":"That conversation will appear on their phone automatically"},
    {"mc":"Okay"},
    {"sarah":"For now i'll just add my phone, if you open it youll see that it updates automatically with what I am saying to you here"},
    # I am simply using code to show the 'button' you can click to access Sarah's phone. Everything that explains how this button works is done is in 'my_gui.py'
    {"code":"sarah_phone_show = True"},
    {"sarah":"But messaging will be completely paused (I mean, you have my phone, i cant message)"},
    {"sarah":"That is optional though"},
    {"sarah":"It's there now by the way, you can go and have a look :) just close this phone completely"},
    {"sarah":"(Mines the purple one c:)"},
    {"sarah":"I'll just loop this chat back to the start now so you choose another option, or continue if youve picked them all"},
    {"sarah":"You can close this phone at any time and check mine to see what I see!"},
    {"code":"""kps_set_conversation_index(sarah_starting_dialogue, 4)
mc_sarah_conversation["current_index"] = 'sarah_starting_dialogue_index_kps_'
mc_sarah_conversation["current_dialogue"] = sarah_starting_dialogue
    """}
]

# Not doing anything new here, just explinations.  

define explain_lable_safe_chat = [
    {"mc":"Explain 'label safe'"},
    {"sarah":"So, i'm sure you already know this, but renpy works off 'labels', and everything that happens happens inside a label"},
    {"sarah":"So USUALLY, when you make a choice it 'jumps' to the label that that choice leads to"},
    {"sarah":"But this whole system uses exactly 0 jumps, and 0 labels. It exists outside of renpy's normal 'game flow logic'"},
    {"sarah":"I'ts a completely custom made choice system using only screen logic"},
    {"sarah":"So even if youre mid conversation with a character in game, open the phone, and make a choice"},
    {"sarah":"Once you close it youll still be there, at the same point in the story"},
    {"mc":"Okay"},
    {"sarah":"It's also completely seperate between each contact on the phone"},
    {"sarah":"You could get to a choice in this conversation, close the chat, go to another chat, make a choice there"},
    {"sarah":"Come back to this one, and the choice will be there, waiting for you, nothing forces you to do anything in any order"},
    {"sarah":"Hence the 'dynamic'"},
    {"mc":"Nice!"},
    {"sarah":"Now you can, if you want, force conversations too. Every conversation has an index created for it"},
    {"sarah":"Its the same as the name of the thread with _index_kps_ added at the end"},
    {"sarah":"So this conversation is called 'explain_lable_safe_chat', so its index will be called 'explain_lable_safe_chat _index_kps_'"},
    {"mc":"So..."},
    {"sarah":"So you can check that index, compare it to the len() of the conversation, and see if its been finished :)"},
    {"sarah":"You could have a game that has nothing to do with texting, but allow a complete texting sim that doesnt interact with the main game at all, and can be accessed at any time"},
    {"sarah":"Or you could force the player to read through and reply to a message before allowing them to continue, both work"},
    {"sarah":"For now im going to loop you back to the start so you can pick another option :) Something will happen after youve been though them all"},
    {"mc":"Okay"},
    {"code":"""kps_set_conversation_index(sarah_starting_dialogue, 4)
mc_sarah_conversation["current_index"] = 'sarah_starting_dialogue_index_kps_'
mc_sarah_conversation["current_dialogue"] = sarah_starting_dialogue
    """}
]

# Again, nothing new. 
define after_choices_chat = [
    {"mc":"Thougt that was it?"},
    {"sarah":"OH YEA, you've picked all the options!"},
    {"sarah":"Also, I made the option you picked not match what you said, you can do that too"},
    {"sarah":"So, couple of features that didn't fit into all those catagories"},
    {"sarah":"If this is your second time playing you may have noticed a little white arrow appear at the top of the screen?"},
    {"mc":"Okay"},
    {"sarah":"Thats the skip button. This system tracks seen messages, cross save, and allows you to skip already seen messages. Same as RenPy text."},
    {"sarah":"Click it and messages will be sent every 0.1 seconds, so pretty fast (can be changed in config.rpy)"},
    {"sarah":"The gallery system uses naming convention to scan your files and create each gallery"},
    {"sarah":"So as long as you name your images correctly, the gallaries will just be there for you when you open the game"},
    {"mc":"Thats cool"},
    {"sarah":"Well, thats all from me! Bye!"}
]


### DEFINING THE CONTACT ###

# THERE IS A HELPER FUNCTION TO DO THIS FOR YOU. EXAMPLE IN THE SIMPLE RPY. YOU DO NOT NEED TO DO THIS

# THIS IS JUST FOR PEOPLE WHO MAY WAY TO MODIFY THIS DIRECTLY. 

# This only needs to be done once, per contact. So if mc and Sarah are talking, no matter how many conversatons they have, no matter how many times you swap new conversations in
# You will always use this one dict. You do not need a new one for each conversation. 
# But for a conversation between mc and someone else, you will need a second one.

# SO WHAT DOES EACH KEY, VALUE DO?!:
#   Name - This... is stupid, but it does some stuff in the backend youll never see, dont worry about it, set it to whatever string you want. HOWEVER, this is what will be shown at the top if it is a group chat!
#   current_index - This is what keeps track of where you are in a conversation thread, and will increment with each message sent. You can set it to None and forget it exists.
#   all_dialogue - This is where the entire conversation you have had is stored. If you clear it then when you re open that contact, it will be empty.
#                  If you want you can pre load messages into it, the exact same way you defined the conversations above, and they will already be in the chat when you first open it!
#   current_dialogue - This is the conversation list we defined above, so when you first open the phone, that is the conversation that is loaded in. It changes automatically after each choice made to the new list.
#                      DO NOT JUST SET IT TO A NEW CONVERSATION MID GAME. THERE IS A LOT HAPPENING IN THE BACKEND AUTOMATICALLY. I HAVE MADE A FUNCTION TO LOAD IN A NEW CONVERSATION. USE THAT. 
#   scroll_to_bottom - Set to False, forget it exists 
#   delay_next_message - Set to False, forget it exists 
#   members - This needs to be a dict, and each item in this dict, needs to be a key, value, with the key as the name of the person, and the value as a dict. So 'members:{'kesash':{}}'
#             Each member name then gets a few values in their dict: 
#                      profile is the image for their profile picture, so put the mc profile picture in the dict for mc 
#                      disable_messaging does what it says, if set to true then when using that persons phone you will not be able to send messages in this chat, and none will be recieved either. 
#                      this is why, during the demo, when you get a hold of Sarah's phone and open the chat with mc, messages just stop sending. This value is set to True for Sarah in that conversation.
#                     
#        Note that the contacts are generated automatically based on the name in memebers, and the name of the owner of the phone matching. So as the phone is defined below with the owner of 'mc'
#        and 'mc' is also a listed as a memeber of this chat, then when you open the contacts on that phone, this chat will be listed. Automatically. You dont need to do anything else. 

# One extra thing I will add here is that conversation index's are now automatically created for the conversation loaded in at game start
# And the continuation after any choice.
# To add more to a conversation dynamically I would reccomend to just use mc_sarah_conversation['current_dialogue'].extend(new_dialogue_list)
# As it will simply extend the current convesation list, and let it continue
# However, if for any reason you need to manually load in an entire new conversation you will need to create and assign an index for that conversation
# The index is ALWAYS the name of the conversation list + _index_kps_, it MUST be. This var SHOULD already exist if the conversation was defined before runtime.  
# And when you assign it to the current index you use A STRING OF THE INDEX VARIABLES NAME. 
# I KNOW THIS SOUNDS WEIRD, BUT RENPY IS STUPID OKAY?

# So if I wanted to load in a conversation list called new_conversation, and that list was already defined, i would need to do....
# mc_sarah_conversation['current_dialogue'] = new_conversaton
# mc_sarah_conversation['current_index'] = 'new_conversation_index_kps_'

# But again, there is a function that does this for you

default mc_sarah_conversation = {
    "name":"mc_sarah_conversation",
    "current_index":None,
    "all_dialogue":[],
    "current_dialogue":sarah_starting_dialogue,
    "scroll_to_bottom": False,
    "delay_next_message": False, 
    "members":{
        "sarah":{
            "disable_messaging": True,
            "profile":"test/test_profile.png"
        }, 
        "mc":{
            "profile":"test/mc_profile.png"
        }
    }
}

default sarah_phone = {
    "gallery": {},
    "name": "sarah",
    "background": ["#470655"]
}


# GROUP CHATS YAY

define group_chat = [
    {"kesa":"Hey"},
    {"kesa":"Welcome to the group chat"},
    {"sarah":"So you'll notice message now say who sent them"},
    {"sarah":"And they are grouped together if the same person sends many"},
    {"mc":"okay"},
    {"sarah":"Also, the group chat name appears at the top, not a contact name"},
    {"code":"group_chat_conversation['name'] = 'Im here too...'"},
    {"system":"Nova changed the group chat name to 'Im here too you know'"},
    {"nova":"Ignoring me after I spent ages making the new UI...."},
    {"nova":"Rude...."},
    {"kesa":"Hey, im giving you a cameo, you're here, calm down"},
    {"sarah":"And as you can see, you, or someone else, can change it"},
    {"mc":"Okay"},
    {"sarah":"Same thing goes for the image for the group chat that you see on the contact list"},
    {"sarah":"The next update WILL improve what this looks like"},
    {"sarah":"Like colour coded bubbles and stuff"},
    {"nova":"I'm not doing anymore. No more. Nope."},
    {"system":"Nova has gone offline"},
    {"kesa":"I THINK I can manage colour changes... dont worry...."},
    {"kesa":"Oh, she ran away"},
    {"sarah":"Thats about it for group chats"},
    {"mc":"Do all the normal message types work here too?"},
    {"sarah":"Yep, the only difference is that an image key will take a second key, value pair"},
    {"sarah":"Just with 'sender':'name of sender'"},
    {"sarah":"So it says who sent it"},
    {"sarah":"Thats all for this chat :) you can leave it and go back to mine now"},
    # make sure the image key, value is first, the sender key value is second. Important. 
    {"image":"test/test_thanks.png", "sender":"sarah"}
]

# Gorup chats are defined the exact same way as a normal conversation, except you also add a 'profile' key, this simply points to the image to use for the group chat :)
# Because we are using that, members dont need a profile image key, value, they would go unused. 
# The colours in the members key, value will eventually be used for chat bubble colours
# (that may be implemented if i forgot to change this comment.....)

default group_chat_conversation = {
    "name":"group chat test",
    "profile":"test/group_test_profile.png.png",
    "current_index":None,
    "all_dialogue":[],
    "current_dialogue":group_chat,
    "scroll_to_bottom": False,
    "delay_next_message": False, 
    "members":{
        "kesa":{
            "colour":"#a84b0e",
        }, 
        "nova":{
            "colour":"#a84b0e",
        }, 
    }
}

