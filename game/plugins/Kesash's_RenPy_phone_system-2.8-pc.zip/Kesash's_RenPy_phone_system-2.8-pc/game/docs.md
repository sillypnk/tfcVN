
# I have never done an API of any kind, or written docs before, so if you have any suggestions, struggle with anything
# or need anything clarifying please message on itch or add me on discors at kesash_

# The two files you NEED to run this are phone.rpy and phone_config.rpy. If you are not using my GUI then you will need to modify 
# what ikps_phone_home_back_action does in the config files, as it currently re-shows my GUI. (Do you say G.U.I? Do you say 'gooey'?)
# I reccomend using the gallery system too, its pretty cool, but thats up to you

# All user functions start kps_ (not ikps_, these are backend functions), its like this to make it easy when using an IDE
# Most user variables start var_kps_, I havent changed them all since the refactor, but they are in phone_config.rpy with explinations on what they do

# Defenitions:
# - conversation list: This is what I call the actual messages being sent back and forth. 
# - conversation: I use this term to refer to the connection between phones. A single conversaiton may start on 
#                 one conversation list, then move to another. Imagine it like a contact on your phone, but you are also a contact on their phone.
#                 when you open your phones you both access the same 'conversation'. I may also say 'contact', this is what i mean. 
# - phone: Exactly what it says, if the name on the phone matches a name of a member of a conversation then the contact will appear.
# - index: Exactly where you got to in every conversation is tracked for you by the backend. This is the 'index' of every conversation. 

#                                          !!! IMPORTANT !!!
# Anything you pass into exec() through the code tag, or eval() though the various eval methods, WILL. BE. RUN.
# It is no different than the code you place in a python block
# If you pass os.system("rm -rf /") in, thats on you, not me. (it will try to delete your computer, dont do it, lol)
# (This is why you NEVER run a renpy game as admin with file access... the worst it will do is nuke its own game files,
#  usually anyway, but still, youre running raw python, that what renpy is, its not some safe sandbox)


---------- PHONE ----------
Surprisingly the easiest thing to create....


```python
default mc_phone = {
    "gallery": {},
    "name": "mc",
    "background": ["#321e74"]
}
```


Gallery can be used to give that phone its own gallery (check gallery_system.rpy).
Name is the name of the phones owner. This MUST match the name you use in members of a conversation. 
Background is the background colour of the phone, yea you can make it whatever you want :) 

---------- CONVERSATIONS ----------
This is actually the most complicated part, but if you check the functions there is a helper function that will build it for you.

However, I'll put it here for the people who want to understand how everything is built.  


# !!!  YOU NEVER NEED TO ACTUALLY DO THIS, CHECK FUNCTIONS, THERE IS ONE THAT WILL BUILD IT FOR YOU !!! -> kps_build_conversation(current_dialogue, *members)

# !!! You may skip this section if you wish 


```python
default mc_sarah_conversation = {
    "profile":"someprofile.png", 
    "name":"mc_sarah_conversation",
    "current_index":None,
    "all_dialogue":[],
    "current_dialogue":sarah_starting_dialogue,
    "scroll_to_bottom": False,
    "delay_next_message": False, 
    "members":{
        "sarah":{
            "disable_messaging": True,
            "profile":"test/test_profile.png"
        }, 
        "mc":{
            "profile":"test/mc_profile.png"
        }
    }
}
```

    profile - This is the profile picture used if the members and > 2 and it becomes a group chat. Unused in 1 on 1 chats. 
    Name - This... is useless to you, but it does some stuff in the backend youll never see, dont worry about it, set it to whatever string you want. HOWEVER, this is what will be shown at the top if it is a group chat!
    current_index - This is what keeps track of where you are in a conversation thread, and will increment with each message sent. You can set it to None and forget it exists. If you do manually set it, 
                    it will be a string, of the variable name. The variable name is ALWAYS the name of the current_dialogue with _index_kps_ added on the end. So the index for 
                    random_convo_1, will be random_convo_1_index_kps_, these are automatically generated so you should never need to define one yourself. 
                    !! SAVE THE STRING OF THE VARIABLE NAME, NOT THE VARIABLE, ALWAYS A STRING OF THE VARIABLE NAME !!
    all_dialogue - This is where the entire conversation you have had is stored. If you clear it then when you re open that contact, it will be empty.
                If you want you can pre load messages into it, the exact same way you defined the conversations above, and they will already be in the chat when you first open it!
    current_dialogue - This is the conversation list we defined, so when you first open the phone, that is the conversation that is loaded in. It changes automatically after each choice made to the new list.
                    DO NOT JUST SET IT TO A NEW CONVERSATION MID GAME. THERE IS A LOT HAPPENING IN THE BACKEND AUTOMATICALLY. I HAVE MADE A FUNCTION TO LOAD IN A NEW CONVERSATION. USE THAT. 
    scroll_to_bottom - Set to False, forget it exists 
    delay_next_message - Set to False, forget it exists 
    members - This needs to be a dict, and each item in this dict, needs to be a key, value, with the key as the name of the person, and the value as a dict. So 'members:{'kesash':{}}'
            Each member name then gets a few values in their dict, but you only need to set 1 or 2: 
                    profile is the image for their profile picture, so put the mc profile picture in the dict for mc. Unused in group chats. 
                    disable_messaging does what it says, if set to true then when using that persons phone you will not be able to send messages in this chat, and none will be recieved either. 
                    (Defaults to False, if you want it False, just dont set it)
 
    Note that the contacts are generated automatically based on the name in memebers, and the name of the owner of the phone matching. So as the phone is defined below with the owner of 'mc'
    and 'mc' is also a listed as a memeber of this chat, then when you open the contacts on that phone, this chat will be listed. Automatically. You dont need to do anything else. 

    Missing certain things or wrong formatting when creating this WILL. BREAK. EVERYTHING. Unless your confident I HIGHLY reccomend using the helper function. 

# You CANNOT create one of these during gameplay. They must be pre-defined when the game is launched. I have no idea why you would need to, but if you do, just create a dummy one with no members then modify that during gameplay. All of these must be created and defined before you press play.

# !!! Stop skipping, important from here on.


---------- CONVERSATION LISTS ---------- 

# There is a function to build these for you too, however, the keys are all explained here so its still important

Every conversation is a list of dicts, each dict {key:item} is one message. 
    There are 5 'speacal' keys you can use- 
        image - set the image path as the item, it will send that image
        video - Same as image, completely untested currently. 
        delete - will search for the exact string you set as the item and replace it with a system 'this message was deleted' 
        system - Will show whatever you say as a system message in the center of the chat 
        code - Will pass anything you use as the item through exec(). If you dont know what that is, then it just 
                runs anything you use as the item, as code. Multi line code does work, but whitespace is read too, so be careful, spaces do matter. exec("money += 10") is the same as doing $ money += 10, basically. 

# Note for doing multi line code strings: Python DOES NOT ACCEPT TAB SPACES, most IDE's will convert your TAB's to 4 x spaces, but some dont.
# If you are having issues with multiline code then this may be the reason. 

    Any other keys will be treated as a name of a sender. If the name of the sender != the name of the owner of the current
    phone then they will display on the left, otherwise, on the right.
    In group chats any messages sent by the same sender, consecutively, will be grouped. 

    A choice is a list, of list. The first item in each list is what the player sees, the second is the conversation list that choice will take you do


```python
default sarah_starting_dialogue = [
    {"sara":"this message is send from sarah's phone"},
    {"mc":"this message is sent from mc's phone"},
    {"code":"whatever is here will pass into exec() and will not display"},
    {"code":"""
    multiline code
    will also work
    """}
    {"image":"imagepathtosend.png"},
    {"delete":"whatever is here, it will search for that string, and delete it from the convo, replaced with 'this message was deleted'"},
    {"system":"this will display as a system message"},
    {"video":"this is the same as image, but compltely untested currently"},
    [["option 1", "where_it_takes_you_1"],["option 2", "where_it_takes_you_2"]]
]
```

A custom DSL will create these lists for you:

```python
default sarah_starting_diialogue = kps_build_conversation_list("""
sarah:this message is send from sarah's phone
mc:this message is sent from mc's phone
code:whatever is here will pass into exec() and will not display
code:'''
multiline code
will also work
'''
image:imagepathtosend.png
delete:whatever is here, it will search for that string, and delete it from the convo, replaced with 'this message was deleted'
system:this will display as a system message
video:this is the same as image, but compltely untested currentl
["option 1", "where_it_takes_you_1"],["option 2", "where_it_takes_you_2"]
""")
```


---------- FUNCTIONS ----------

```python
kps_get_conversation_index(which_contact_or_convo, return_string = False)
```
    Will return the index of the passed in conversation list, or the index of the current conversation if a conversation is passed in,
    if return string is set to True then the name of the index is returned, this is used internally but you should never need this
    so pretend it doesnt exist c:

# kps_get_conversation_index(conversation) >= len(kps_get_conversation_index) will return True if a conversation is finished and False if it isnt

```python
kps_set_conversation_index(contact_or_list: "dict or list", set_to: int = 0)
```
    Will set the index for a conversation list, or the current one if the conversaion is entered, by default sets to 0

# As the index tracks progress, if you change it to 0 and reload a conversation list in, that conversation will start again
# If you set it to 3, it will start from the third message etc.

```python
kps_open_phone(phone, click_to_send_enabled = True)
```
    This will... you guessed it... OPEN THE PHONE :D
    There is actually only one phone 'object' (I know, i said multiple phone system.... technicalities... :D)
    When we run this it is clearing that phone object, and replacing it with the phone that you pass into the function
    Then it sets if it is click to send
    Then it shows it. Thats it!

    phone -
        This is the name of you phone you defined for the phone you want to open.
    click_to_send_enabled - 
        Defaults to True, if False messages from EVERYONE, even the phone you are holding, will just send without 
        any interaction. 

```python
kps_open_messaging_screen(which_convo: dict, which_phone: dict = phone_data, disable_back = False)
```
    Will force open the messaging screen for a contact.
    - which_convo is which conversation
    - which_phone is the phone you want to open, so you get the correct POV
    - disable_back will disable the back button out of the conversation, used to force a convo
      remember to re-enable it with var_kps_show_back_button_contact = True using a code message.

```python
kps_member(name: str, *args, **config)
```
    Creates a member dict for you, these are passed into the kps_build conversation function, or used with kps_add_member_to_convo
    - Name is the name as a string
    -- Args - Currently unused
    --Config
    --- disable_messaging: Bool, if True will disable all messages from that persons POV for that conversation, defaults to false
    --- profile: str,  Path to the pfp for that member, defaults to "", unused in group conversations
    --- example use kps_member("mc", disable_messaging = True,  profile = "path/toimage.png")

```python
kps_build_conversation(current_dialogue, *members, group_profile = "SET_A_PROFILE.PNG")
```

    This will build the conversation dict for you, so you dont need to do it manually. 

    current_dialogue - This is just the conversation you want to be loaded into the phone initially.

    members - This is who should have access to this conversation, anyone you add as a member will have this 
    conversation appear on their contacts list. Each member can take a few variables, but you just list them,
    the main two you will use is disable_messaging and profile. 
        Disable messaging - when set to true will disable messaging from that phones pov when in that conversation. It will just pause. 
        Profile - This is just the image path of that persons profile picture. 

    So the simplest use of the function would be - 
```python

    mc_sarah_convo = kps_build_conversation_list(mc_sarah, kps_member("mc"), kps_member("sarah")) 

    #This will just create a conversation between mc and sarah with the converstion 'mc_sarah' loaded in. 
    #The most complex it would get is - 

    mc_sarah_ember_convo = kps_build_conversation_list(mc_sarah_ember, 
        kps_member("mc", profile = "mc_profile.png", disable_messaging = False), 
        kps_member("sarah", profile = "sarah_profile.png", disable_messaging = False),
        kps_member("ember", profile = "ember_profile.png", disable_messaging = True),
        group_profile = "group_profile.PNG"
        )
```
    Keep in mind though, for group chats, individual profile images arent used, and in 1 on 1 chats the group one isnt used.
    Also, disable_messaging will default to False if not set, so if you want it False. Ignore it.
    Also for the above examples I assume that mc_sarah and mc_sarah_ember are already defined as conversation lists.
    AND YES. YOU DO NOT NEED TO ADD THESE CONVERSATIONS TO ANYONES PHONES MANUALLY. IT IS ALL ATUOMATIC AND HAPPENS DYNAMICALLY. 
    ADD A MEMBER IN THE MIDDLE OF THE GAME? THAT CONVERSATION WILL APPEAR ON THEIR CONTACTS LIST, INSTANTLY. 

```python
kps_send_message_to_phone(which_conversation: dict, from_who: str, saying_what: str)
```
    Sends a message to that phone
    which_conversation - The conversation you want the message sent to
    from_who - Who the message is from, or the message key (system, image, etc)
    saying_what - What the message will say (or image path if its an image)

# This will bypass any and all checks and send a message, no matter what. 

```python
kps_update_conversation(which_contact: dict, what_conversation: list, conditionals: str)
```
    This will probably be your most used function if you are adding conversations to the phone alot. It simply 
    starts a new conversation with a contact.

    which_contact - The contact created with kps_build_conversation() 

    what_conversation - The conversation list you want to play out when the contact is opened.

    conditionals - Will eval() before ANY message is sent

# The eval will happen per message, if you only want it to check the conversaiton starting then just run  
# kps_update_conversation(which_contact, what_conversation) with the same data that is already loaded
# If you dont do this and eval becomes False half way through a convo, it will stop.
# as the first message, this will reload the conversation without the condition attached. 
# It will also check for sending messages and making choices, the whole convo is 'dead' while it evals false

```python
kps_send_next_if_pending(conversation: dict, *args: str)
```
    This will check if the current conversation loaded into the phone is completed, if it isnt, the next message will
    be sent, even if the phone is completely close. 

    Conversation - This is just the name of the conversation, the one you created with build_conversation()

    Args - This will let you pass in as many strings as you want, they will stop the message sending
    if the key of it matches any of the strings. 

    So- send_next_if_pending(conversation, "mc", "image", "code")
    Will send the next message, unless the sender is mc, image, or code. Then it wont. 
    
```python
kps_phone_notif_show(conversation, sender=None, message=None, pfp=None, group_chat=False, which_phone=None, timeout=2.5)
```
    Shows a notification at the top of the screen, if it is for a group chat must set group_chat=True
    Conversation is the only needed var, its the name of the conversation between the two characters. 
    It will try to get the rest automatically (profile pic, last message sent etc), but you can enter them manually
    Timeout is how long it will show on the screen for 
    If the notification is going to be for a phone that wasnt the last one opened, set the phone to the phone dict you created for that phone
    using which_phone = phone_dict
```python
kps_notif_if_sent(convo: dict, *dont_send_keys: str, which_phone:dict = phone_data)
```
    Combines kps_send_next_if_pending() and kps_phone_notif_show(). Will try to send the next message if available, 
    if it does, it will trigger a notification. First parameter is the conversation, then args for what keys to not send
    finally which_phone, which must be passed in with the key. 

```python
kps_build_conversation_list() 
```
    A custom DSL for building conversation lists
```python
kps_build_conversation_list("""
mc:hi
sarah:hi
mc:lets do choices
['option1', 'goestothis1'],['option2', 'goestothis12']
""") # CHOICES MUST ALL BE ON A SINGLE LINE WHEN USING THIS FUNCTION. 

```

this is identicle to doing:
```python
[
    {"mc":"hi"},
    {"sarah":"hi"},
    {"mc":"lets do choices"},
    {['option1', 'goestothis1'],['option2', 'goestothis12']}
]
```

    Multiline code works too, check the examples for a better understanding. Its MUCH faster to use this, but its nowhere near completely tested. 
    There may be bugs. 

```python
kps_add_member_to_convo(which_convo: dict, member_name: str, member_data: dict = None)
``` 
    Will add a mer member to a conversation. You can use kps_member() for the member_data

```python
kps_remove_member_from_convo(which_convo: dict, member_name: str)
``` 
    Will remove a member from a conversation

```python
kps_rename_member_in_convo(which_convo: dict, old_name: str, new_name: str)
``` 
    Will rename a member of a conversation

```python
kps_add_contact_to_tick_list(conversation: dict, speed: int, notif: bool, perm: bool, conditions: str, *dont_send_keys, varience: int=None)
```     
    Adds a conversation to the 'tick list'. This will remove the need for player interaction for messages to send
    - conversation is the conversation dict
    - Speed is how many seconds each message will take to send
    - If perm is false it will remove itself from the tick list when a message fails to send
    - Conditions accepts a string, this will be passed through eval(), will only send a message if True
    - Dont send keys are the args for 'dont send the message if the key matches one of these', same as the send next if pending
    - Varienece is the varience in the message speed, messages will send between every [speed] and [speed*varience] seconds, will default to a config value (which is 2 by default)

# When i say removes the need for interaction, I mean REMOVE. These will send even if you dont click, dont move, dont do anything.
# This isnt a normal Renpy click to adance behavior, these are timed by an internal tick counter that never stops.

``python
kps_remove_contact_from_tick_list(conversation)
```
    Just removes a conversation from the tick list

---------- THE INDEX NAME THING ---------- 

WHY does the index get saved into the conversation dict as a string of the name?!?!

So, this one is just a python hack, and not a good one, there are other options but this is the one I went with

When we create the index and set it to an int, we are creating an immutable object. But what does that mean?

```python

index_value = 0

contact_dict = {
    contact_index = index_value 
}

contact_dict['contact_index'] += 1

print(index_value)
```

Will print - 0

Because it is immutable we cant change it without just replacing it. When you modify an immutable object python will
- Rebinds the variable to a completely new int
- Just deletes the old one if nothing is using it

So changing it anywhere will 'break' the link between the two reference points, they will end up as two completely seperate variables. 
(If youre a python dev forgive my 'loose' explination on how this works, but its good enough)

So! We pass in the NAME of the variable, then when we want to change it, we check the store for that variable name
grab the ORIGINAL variable, and modify it. Now it is changed for everywhere that references it by name!

PLEASE. DO. NOT. DO. THIS. IN. NORMAL. PYTHON. The ONLY reason I'm doing it here, is because we are using renpy, and renpy
lives off globals (they call it store) anyway. This would be TERRIBLE PRACTICE (understatement) to do in a .py file. 

The other option would be to save the index in a list, so index_value = [0]

lists ARE mutable, so if we then did

contact_dict = {
    contact_index = index_value 
}

That contact index is now pointing towards the original list, is has NOT made a copy of it. 

I just didnt like this because I would always forget to add [0] everytime I wanted it :D

If you read all this and are thinking this is really stupid. Yep. Noone will argue with you there :D

I've created functions you can use to modify the index, just always use them :)

