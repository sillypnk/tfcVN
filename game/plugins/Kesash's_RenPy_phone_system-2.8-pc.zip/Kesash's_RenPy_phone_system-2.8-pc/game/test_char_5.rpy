
### This was just me messing around with some concepts of what you can and can't do. 
### After a while I reaslised the general rule is

python:
    def can_you_do_it():
        return "Yes"

### I mean I shared this with people, and they messaged me trying to get something to work, and what they were doing were things I had never even considered. 

### So this is just to give you some ideas. 

### This 'demo' will be using labels and actually playing through a 'game', you will be lead here after finishing all the conversations with Sarah




label advanced_conversations_menu:
    $ mc_nova_conversation['current_dialogue'] = []
    menu:
        "What would you like to see?"
        "Notifications":
            jump notifications_example
        "Characters responding to being ignored(NEW!!)":
            jump ignoring_nova
        "Two phone conversations interacting with each other":
            jump two_phones_interacting
        "Forced conversation":
            jump forcing_a_conversation
        "Conversation mutation with phone closed":
            jump phone_closed_mutation
        "Time based messaged (NEW!)":
            jump time_based_messages
        "Conditional messaging(NEW!)":
            jump conditional_messaging
        "Some fun stuff that I dont know how you'd use?":
            jump fun_stuff
        "Final thoughts":
            jump final_thoughts

label not_implemented:
    kesash "If you're seeing this, I either havent made this part yet, or forgot to change the jump label... Who knows really...."
    jump advanced_conversations_menu





###################### notifications_example ##############################
label notifications_example:
    "Label for this section is notifications_example"
    kesash "SO! Notifications, this one is pretty simple, the function takes the conversation and the phone you want to open it on as arguments"
    kesash "If you don't set which phone, it will automatically show from the pov of the last phone you opened"
    kesash "So if youre only using a single phone, you don't need to worry about setting it every single time"
    $ kps_send_message_to_phone(mc_nova_conversation, "nova", "Apparently I have to message you? Soo... hey")
    # First argument is the conversation, second is which phone it opens when you click it (because every convo has 2 sides, need to say which side to open it from)
    # By default it will use the last phone opened as the second argument. There are LOTS of other things you can pass in too, like the pfp, the message they see, the name, etc, check the docs. 
    $ kps_phone_notif_show(mc_nova_conversation, which_phone=mc_phone)
    kesash "See it? If you missed it, roll back, and click it. It will open the conversation."
    kesash "Just to note that notifications aren't automatic when a new message is added, because you might not want one to show"
    kesash "If you do want one to show just add the message and use the kps_phone_notif_show function at the same time like I just did here"
    $ kps_send_message_to_phone(mc_nova_conversation, "nova", "Did your notifications break?")
    kesash "You just recieved another message from Nova without a notification showing"
    kesash "Just to show you that its possible"
    kesash "Alright, i'll throw you back to the menu now so you can pick a different option!"
    jump advanced_conversations_menu
##########################################################


###################### ignoring_nova ##############################
default nova_not_ignored = kps_build_conversation_list("""
mc:Hey
nova:You didn't ignore me!
nova:Thanks!
""")

default nova_ignored = kps_build_conversation_list("""
mc:Hey
nova:Too late, you ignored me :c!
system:User has gone offline
""")

# I set these to send on a 10 second timer, so every 10 seconds, the conevrsation that will be available is swapped out,
# (see timed based messages)
# Code messages dont trigger notifications, ever, so this will be invisible.
# Why doesnt this just swap the messages out instantly though? How do the rest trigger after the first?
# Well because code messages sent to a closed phone dont trigger till the contact is opened
# And they will execute top to bottom, so if all of these have sent it will swap it out till it gets to the last one
default nova_ignored_timer = kps_build_conversation_list("""
code: kps_update_conversation(mc_nova_conversation, nova_ignored_timer_fast)
code: kps_update_conversation(mc_nova_conversation, nova_ignored_timer_medium)
code: kps_update_conversation(mc_nova_conversation, nova_ignored_timer_slow)
""")

default nova_ignored_timer_fast = kps_build_conversation_list("""
mc: Hey
Nova: That was a fast reply!
""")

default nova_ignored_timer_medium = kps_build_conversation_list("""
mc: Hey
nova: Took your time!
""")

default nova_ignored_timer_slow = kps_build_conversation_list("""
mc: Hey
nova: WOW, you took FOREVER to relpy
""")

$ kps_update_conversation(mc_nova_conversation, )

label ignoring_nova:
    "Label for this section is ignoring_nova"
    kesash "Okay, you're about to get a notification from Nova, open it and reply"
    # Sending a message with the phone closed, just append to the all_dialogue
    $ kps_send_message_to_phone(mc_nova_conversation, "nova", "Hey Again!")
    # Showing the notification for this message
    $ kps_phone_notif_show(mc_nova_conversation, which_phone=mc_phone)
    # Updating the 'waiting' conversation, so this is what will play out when you open the phone, first parameter is the contact/conversation, second is the conversation list. 
    $ kps_update_conversation(mc_nova_conversation, nova_not_ignored)
    kesash "Did you reply?"
    kesash "Last chance."
    # Checking if the index has incremented on the current convesaion. If it hasn't, you didnt reply :c You need to use this function to get the current index of the conversation
    # The alternative is getattr(store, mc_nova_conversation['current_index']), which is all this function does, this is just easier. 
    if kps_get_conversation_index(mc_nova_conversation) >= 1:
        jump nova_not_ignored
    else:
        jump nova_ignored


label nova_not_ignored:
    kesash "looks like you did"
    kesash "After finishing this section, ignore her next time, her replies will have changed by this point"
    # Here I am manually resetting the index for the conversaion list, you only need to do this if you are reusing conversations, like I am here
    # The first parameter is the convact/conversation, the second is what to set the index to. As I passed in the contact it will update the currently loaded conversation
    $ kps_set_conversation_index(mc_nova_conversation, 0)
    jump ignoring_nova_timer


label nova_ignored:
    # We checked the index, saw you hadnt replied, so we swapped out the conversation
    $ kps_update_conversation(mc_nova_conversation, nova_ignored)
    kesash "ohh, you ignored her"
    kesash "Open the phone and reply now, her replies will have changed"
    kesash "Now you might have noticed what I said changed too, based on if you replied."
    kesash "I did this by jumping to a different label based on if you did or didn't, but you don't have to"
    kesash "You can stay in the same label and just change what the text replies are."
    # You might notice here, when I reset the index I am passing in the name of the conversation list? Yep. That works too.
    # Pass in the contact and it will reset the current conversation index, pass in the actual list name and it will reset it for that list. 
    # I also didnt pass in a second parameted, if you dont it will set to 0
    $ kps_set_conversation_index(nova_ignored)
    $ kps_set_conversation_index(nova_not_ignored)
    jump ignoring_nova_timer

label ignoring_nova_timer:
    kesash "Now that was based on if you replied by a certain point in the label, but what if we changed that..."
    kesash "And base it off how long you take to reply, in seconds, regardless of if you click or not...."
    kesash "Soon she will message you again, then, every 10 seconds, in the background her replies will be being swapped out"
    kesash "You wont actually see this, but try replying straight away, then wating 20 seconds, then more than 30"
    kesash "Her replies will have changed (rollback to here, then click once to test this)"
    # Send a message
    $ kps_send_message_to_phone(mc_nova_conversation, "nova", "Hey again")
    # Make it cause a notification
    $ kps_phone_notif_show(mc_nova_conversation, which_phone = mc_phone)
    # Add the convo that causes the messages to swap
    $ kps_update_conversation(mc_nova_conversation, nova_ignored_timer)
    # Make it trigger every 10 seconds
    $ kps_add_contact_to_tick_list(mc_nova_conversation, 10, True, True, None, "mc", varience = 0)
    kesash "Alright, she is messaging you again now, no need to click anymore"
    kesash "....."
    kesash "Done?"
    kesash "Now I used seconds here, because It's just a demo, but you could do minutes, hours, days even..."
    kesash "Back to the menu!"
    $ kps_set_conversation_index(nova_ignored_timer_slow)
    $ kps_set_conversation_index(nova_ignored_timer_medium)
    $ kps_set_conversation_index(nova_ignored_timer_fast)
    $ kps_set_conversation_index(nova_ignored_timer)
    # Im just clearing any code left in the convo here and forcing it to run without opening the phone so that it resets cleanly if you loop
    $ handle_message_types(mc_nova_conversation['all_dialogue'])
    jump advanced_conversations_menu
##########################################################




###################### phone_closed_mutation ######################
default nova_counting = kps_build_conversation_list("""
nova:1
nova:2
nova:3
nova:4
nova:5
nova:6
nova:7
nova:8
nova:9
nova:10
""")

label phone_closed_mutation:
    "Label for this section is phone_closed_mutation"
    kesash "Alright, lets change some things while the phone is closed"
    kesash "First I can make a conversation continue happening even if you dont have the phone opened"
    # Just setting the new conversation to the one I made above
    $ kps_update_conversation(mc_nova_conversation, nova_counting)
    kesash "I've just loaded a new conversation in for Nova, its just her counting to 10...."
    # kps_send_next_if_pending will see if there is a message waiting to be sent, and send it. If there is and it does it will return true. Using it here for notification logic.
    # It also takes args for keys to skip. So kps_send_next_if_pending(mc_nova_conversation, "mc", "image") will only send the next message if the key ISNT mc or image. 
    # (You will only need to use this function though if you DONT want a notification. See next note.)
    if kps_send_next_if_pending(mc_nova_conversation):
        $ kps_phone_notif_show(mc_nova_conversation, which_phone = mc_phone)
    kesash "If you open the phone now, you will just... watch it happen...."
    # But thats effort. So I just made a function that does both. Will try to send another message, if it can, will send a notification.  
    # which_phone must be passed with its key, so 'which_phone =', as this still takes args for message senders or types to skip. 
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "But you have probably noticed, if you didnt do that, she is sending the messages anyway...."
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "you don't need to have the phone open for a conversation to continue"
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "So you have the choice to open it and watch her sending these messages"
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "Or just leave her to talk to herself....."
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "Why did I make it to 10...."
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "Ive got to pad this out so much now... Ill just make her send the last 3 all at once (assuming you didnt open the phone)"
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    $ kps_notif_if_sent(mc_nova_conversation, which_phone = mc_phone)
    kesash "AND DONE, even if you didn't open the phone she will have sent all her messages"
    kesash "But it's not just one message at a time, you can control the entire conversation, in any way you want, based on where you are in a label"
    kesash "So... lets say your character got drunk, woke up the next morning, and checked their phone..."
    # I COULD use multiple kps_send_message_to_phone() here, but I chose to just modify the dict directly, both work, whichever you prefer
    # Adding the "seen":True on the last item just stops the 'slide in' animation from happening when you open the phone. 
    $ mc_nova_conversation['all_dialogue'].extend([{"mc":"Hetrhn"},{"nova":"???"},{"mc":"heeyyeoyrp"},{"mc":"Noaoabavaaaa"}, {"nova":"?!?!??!?!", "seen":True}])
    kesash "You can do that too... (check your chat with Nova again....)"
    kesash "Or replace messages with something else?"
    # Just itterating over all dialogue and replaceing any message she sent with the default deleted message
    python:
        for i, message in enumerate(mc_nova_conversation["all_dialogue"]):
            if any(key in message for key in ("nova", "image")):
                mc_nova_conversation["all_dialogue"][i] = {
                    "system": "This message was deleted"
                }
    kesash "She just deleted every message she has ever sent you"
    kesash "Go check"
    kesash "She might even just... delete you..."
    # Remember the contacts are loaded in based on if the name of the phone owner == a name on the member list of a convo
    # By removing mc as a member, this conversation will no longer appear on his phone. 
    # If you also had access to Nova's phone you would need to remove her too, then add you both back, but we dont so just mc is enough. 
    $ mc_nova_conversation['members'].pop("mc", None)
    kesash "I mean, she isnt on your contact list anymore at all...."
    kesash "Checked? Cool, cos i'm adding her back now"
    # Just adding him back in, we dont have Nova's phone so no point setting a profile... 
    $ mc_nova_conversation['members']['mc'] = {}
    kesash "And she's back! It even kept all the message history"
    kesash "I think thats enough for now, but the point is that there are no limits to what you can do"
    kesash "Well, back to the options!"
    # Resetting the index again so you can redo this if you want. kps_set_conversation_index(nova_counting) would have worked here too.
    $ kps_set_conversation_index(mc_nova_conversation)
    jump advanced_conversations_menu
##########################################################


###################### two_phones_interacting ##############################

# I believe everything im doing here is explained in previous notes :) 
# Im just doing it using code blocks here with the phone open

 
default two_phone_interaction_nova = kps_build_conversation_list("""
nova:Alright... interactions between phones...
nova:I guess the easiest option is to get Iris to message you?
nova:1 sec....
code:'''
kps_send_message_to_phone(mc_iris_conversation, "iris", "Hey")
kps_update_conversation(mc_iris_conversation, two_phone_interaction_iris)
kps_add_contact_to_tick_list(mc_iris_conversation, 7, True, True, None) 
kps_add_contact_to_tick_list(mc_nova_conversation, 5, True, True, None) 
'''},
nova:She will have just messaged you
nova:Now no matter which chat you open, we will both continue to message you
nova:Now no matter what you do, we will both continue to message
nova:No matter whos contact you have open...
nova:Or even if you close the phone and dont click at all.....
nova:Which I think is cool?
nova:Thats all from me for this conversation
""")

# I wrote this demo using the old system to create conversations, I got bored of changing them at this point
# Just take the rest of examples of the old way :') it's still fully supported

# Tick list explained in different label

default two_phone_interaction_iris = [
    {"iris":"Now me and Nova both have conversations..."},
    {"iris":"But just because you closed her chat doesn't mean she can't still message you"},
    {"iris":"What kind of phone needs you to open it to recieve messages?!"},
    {"iris":"See how were both messaging you at the same time?"},
    {"iris":"I think thats cool"},
    {"iris":"Last message, you can keep going now"}
]


label two_phones_interacting:
    "Label for this section is two_phones_interacting"
    kesash "Alright... need two free phones for this one so im clearning any remaining dialogue with Iris as well"
    $ mc_iris_conversation['current_dialogue'] = []
    $ kps_update_conversation(mc_nova_conversation, two_phone_interaction_nova)
    # Figuered if put member mutation here too :)
    $ kps_remove_member_from_convo(mc_sarah_conversation, "mc")
    $ kps_remove_member_from_convo(mc_kesash_conversation, "mc")
    kesash "You have some new conversations on your phone"
    kesash "I've temproreraly removed all other contacts from your phone too, so I'ts easier to just swap between them"
    kesash "I'll add them back at the end"
    kesash "Just going to leave some blank messages so you dont accidently click back to the menu"
    kesash "Because when that happens I unload the conversations...."
    kesash "3"
    kesash "2"
    kesash "1"
    kesash "These conversations aren't forced (thats another path) so dont click here again until youve finished them!"
    $ kps_add_member_to_convo(mc_sarah_conversation, "mc")
    $ kps_add_member_to_convo(mc_kesash_conversation, "mc")
    kesash "Alright, I added the contacts back!"
    kesash "and back to the menu!"
    $ mc_iris_conversation['current_dialogue'] = []
    # If you dont know why this works, just put them on 2 seperate lines :) It will only work with certain functions, so dont just copy it.
    $ kps_remove_contact_from_tick_list(mc_nova_conversation) or kps_remove_contact_from_tick_list(mc_iris_conversation)
    jump advanced_conversations_menu

##########################################################

###################### forcing_a_conversation ##############################

default nova_forced_1 = [
    {"nova":"Hey, until youve replied to me, you can't leave this label c:"},
    {"nova":"Go check if you want, close the phone, click, wont do anything"},
    {"nova":"Alright, reply, and you can move on"},
    {"mc":"Okay"}
]

default nova_forced_2 = [
    {"nova":"So this is the second way!"},
    {"nova":"How, you ask?"},
    {"nova":"Well... try closing the conversation...."},
    {"mc":"I cant"},
    {"nova":"Nope, want me to re-enable it?"},
    {"mc":"Yes..."},
    # Re-enabling the back button for the conversation screen
    {"code":"var_kps_show_back_button_contact = True"},
    {"nova":"Done! You can leave now"}
]

default nova_forced_3 = [
    {"nova":"So this is the third way!"},
    {"nova":"But isn't this the same as the second way?! NO!"},
    {"nova":"Try closing the phone...."},
    {"mc":"I cant"},
    {"nova":"Nope, which means you can force the phone open, until something has happened"},
    {"nova":"So force someone to finish a branching dialogue with multiple people, or anything else"},
    {"nova":"Because it's only the back button on the home screen thats disabled"},
    {"nova":"Want me to re-enable it?"},
    {"mc":"Yes..."},
    # Re-enabling the back button for the home screen
    {"code":"var_kps_show_back_button_home = True"},
    {"nova":"Done!"}
]

label forcing_a_conversation:
    "Label for this section is forcing_a_conversation"
    kesash "Alright, there are a few ways to do this, i'll show you 3."
    kesash "The first is im just going to throw you into a new label that loops until you have finished a short convo with Nova"
    # Done this one enough by now I think
    $ kps_update_conversation(mc_nova_conversation, nova_forced_1)
    jump forcing_a_conversation_2

label forcing_a_conversation_2:
    # Checking the index of the convresation, comparing it to its length, if the index is lower, its not finished yet
    if kps_get_conversation_index(nova_forced_1) < len(nova_forced_1):
        pause(0.5)
        " "
        # Normal renpy loop
        jump forcing_a_conversation_2

    else:
        # Exit the loop
        jump forcing_a_conversation_3

label forcing_a_conversation_3:
    kesash "That was the first way!"
    kesash "This is the second way...."
    # This variable decides if the back button on the conversation screen is usable, False means it isnt
    $ var_kps_show_back_button_contact = False
    # Same again... update convo....
    $ kps_update_conversation(mc_nova_conversation, nova_forced_2)
    # Disabling the phone ui so you cant open Sarah (if you have it yet) and get stuck
    call hide_all_gui from _call_hide_all_gui 
    # Function for directly opening the messaging screne. That third input decides if the back button is disabled
    # If you call this and disable it remember to re-enable it at some point. 
    $ kps_open_messaging_screen(mc_nova_conversation, mc_phone, True)
    # Im having some issues with the say box not closing when calling the phone using python, for now, this fixes it....
    " "
    kesash "And the third way"
    # Same as the last one but this var convrolls the back button for the entire phone
    $ var_kps_show_back_button_home = False
    # Yep... same again...
    $ kps_update_conversation(mc_nova_conversation, nova_forced_3)
    # Then we just use the open phone function to force the phone open, home back button is disabled, they cant close it
    call hide_all_gui from _call_hide_all_gui_1 
    $ kps_open_phone(mc_phone)
    " "
    kesash "And thats the 3 ways I thought of! There are probably more...."
    kesash "Back to the menu!"
    $ kps_set_conversation_index(nova_forced_1, 0)
    $ kps_set_conversation_index(nova_forced_2, 0)
    $ kps_set_conversation_index(nova_forced_3, 0)
    jump advanced_conversations_menu

##########################################################

###################### fun_stuff ##############################

label fun_stuff:
    "Label for this section is fun_stuff"
    kesash "So, I thought I'd keep this here to add things I just 'discovered' while I was playing around with it."
    kesash "So the first is that you can queue up code to trigger when a contact is opened..."
    kesash "Now why would you want to do this? Idk... But ill show you"
    # Code added directly to the sent messages list will run on contact open. Useful? IDK!
    $ mc_nova_conversation['all_dialogue'].append({"code":"money += 1000"})
    kesash "I just added some code that will increase your money by 1000"
    kesash "But it wont trigger until you open your conversation with Nova"
    kesash "Open her contact and watch the counter in the top right"
    kesash "If you played an older version you'll know this wasnt completely consistant, it now is."
    kesash "Done? Cool."
    kesash "Obviously you can track things like that there are now [len(mc_sarah_conversation['all_dialogue'])] messages in your chat with Sarah"
    $ i = 0
    python:
        for x in mc_sarah_conversation['all_dialogue']:
            for key, item in x.items():
                if key == "sarah":
                    i += 1
    kesash "and that [i] are messages she sent you..."
    $ next_message = "didn't"
    if kps_get_conversation_index(nova_conversation_1) == 3 or kps_get_conversation_index(nova_conversation_2) == 3:
        $ next_message = "did"
    kesash "and that you [next_message] complete the original chat with Nova before I reset her dialogue"
    kesash "And... as you can tell by what im doing, you can mutate chats based on what's happened in the phone"
    kesash "And not just little things, like... did you do the initial chat with Iris where you picked an option"
    $ next_message = "Nope... you didn't.... but if you had id have told you which option you picked"
    if kps_get_conversation_index(iris_choice_1) > 2:
        $ next_message = "You did! And... you picked option 1...."
    if kps_get_conversation_index(iris_choice_2) > 2:
        $ next_message = "Yep, you did, and you went with option 2."
    if kps_get_conversation_index(iris_choice_3) > 2:
        $ next_message = "Looks like you picked option 3"
    kesash "[next_message]"
    kesash "And that isnt me saving variables when you select the option, but just checking the indexes of the conversations that each option leads to"
    kesash "if you restart the game and come straight here, you can rollback, chat with them, then watch the numbers change each time"
    kesash "I could even tell you if you started a convesation, didn't finish it, how far into it you got etc"
    kesash "And this is all tracked for you, you dont need to do anything."
    kesash "I mean, the skip function works by remembering every message youve EVER seen, cross save"
    kesash "So if you really wanted you could make people say different things the second time they have played the game"
    kesash "Or if a message has been read that tells them about something, the character can already be aware of it next playthrough"
    kesash "Well, thats it for my ideas. Back to the menu :)"
    jump advanced_conversations_menu

##########################################################

###################### final_thoughts ##############################

label final_thoughts:
    kesash "Well, thats it from me. What I've tried to show is that this system sits alongside RenPy"
    kesash "So if you want them seperate they are, but if you want to tie them together, you can"
    kesash "Everything from contacts to messages to the gallery... all of it can just be modified however you want"
    kesash "Also, check your message history... Doesn't matter what order you picked options, if you went through some 5 times"
    kesash "It will just stay persistant and keep adding on (You can cut it, but it would need to get LONG to cause performance issues)"
    kesash "If you think of something cool, or want to know how to do something, please let me know"
    kesash "And... I REALLY want to play your games, so please leave a comment on itch if you're making one"
    kesash "It gives me the motivation to continue development"
    kesash "Future plans are things like a social media app, able to enable and disable all apps at will..."
    kesash "I do already have a working 'tinder like' dating app, but its just not good enough yet, and I havent worked on it in a while"
    kesash "But again, leave a comment, let me know if there's anything you want added. If its something I can add, and I have the time, I will"
    kesash "Ill loop you back to the menu just in case you want to try some more things out, but thats it from me. BYE! -^^,--,~ (obligatory fox)"
    jump advanced_conversations_menu
##########################################################

###################### time_based_messages ######################
default nova_time_based_message = kps_build_conversation_list("""
nova: Hey
nova: Sooooo
nova: Im just going to keep messaging
nova: No matter what you do
nova: Dont click? Doesnt matter
nova: Open the phone, ill still send these
nova: Go talk to someone else? Yep, ill still be messaging
nova: How many more of these do I need to send?
nova: Who knows.....
nova: Guess Ill just keep messaging
nova: Feels like im talking to myself here
nova: WAIT, I AM??!!
nova: Okay, no more, im done!
nova: Byeeee
""")


label time_based_messages:
    "Label for this section is time_based_messages"
    kesash "SO, this is actually my favorite feature so far"
    kesash "Forget needing to click, to do things by a certain 'point'"
    kesash "Put it on an actual CLOCK!"
    kesash "After youve clicked one more time, dont click again, just wait"
    $ kps_update_conversation(mc_nova_conversation, nova_time_based_message)
    # First arg is the conversation, second is the timer (every 5 seconds), third is saying 'if a message doesnt send, keep this on the tick list?'
    # If false it will auto remove itself at the end of a convo, if true it will stay there until you remove it
    # The fourth is a condition, any string that can eval, they wont send if it evals False (it checks EVERY message)
    # Unsure? Just set it to None. After that are the 'dont send keys' same as kps_send_next_if_pending(), 
    # just an args list for 'dnot send the message if this is the sender'
    $ kps_add_contact_to_tick_list(mc_nova_conversation, 5, True, None, None, "mc")
    kesash "Now, wait, dont need to click, its on a timer now, she will keep messaging no matter what you do"
    kesash "Even if you went to another label, opened another conversaton, opened her conversation...."
    kesash "She will just keep messaging :)"
    kesash "This also passes through message conditionals (its an option on the menu if you havent done that one yet)"
    kesash "Back to the menu!"
    $ kps_remove_contact_from_tick_list(mc_nova_conversation)
    jump advanced_conversations_menu

##########################################################

 

###################### conditional_messaging ######################

default nova_conditional_messages = kps_build_conversation_list("""
nova: Hey
nova: Ill only message if you have more than 500 money
nova: Wait... that makes me sound really bad doesnt it?!
nova: ITS NOT MY FAULT I WAS PROGRAMMED LIKE THIS!!!!
nova: And you cant reply either if you dont.... try to reply with less, then more-
mc: Oh yea
nova: See! Not just me!
code: '''kps_send_message_to_phone(mc_nova_conversation, "nova", "WELL, NOW I WONT MESSAGE AGAIN UNTIL YOU HAVE LESS THAN 100!") 
kps_update_conversation(mc_nova_conversation, nova_conditional_messages, "money < 100")''' 
nova: Awww youre poor again :c
nova: Sad....
nova: Well, thats it for this example
""")

default nova_conditional_messages_2 = kps_build_conversation_list("""
code: '''kps_send_message_to_phone(mc_nova_conversation, "nova", "Now that this message has sent, the condition is removed")
kps_update_conversation(mc_nova_conversation, nova_conditional_messages_2, "not False and True and True")
'''
nova: So you had to have < 0 money to start this one... but even if i set your money above
code: money = 300
nova: Like that. I can still message :)
nova: So you can have every message on a condition, change/ conditions mid convo, or even remove them completely
nova: Whenever you want!
""")

# One note about this is im updating the convo... with the same convo??? Wont that restart it??? 
# NO, because indexes for conversations are tracked, and stored, perminantly. Unless you reset an index yourself any conversation list will continue from where you got to
# All im doing when I switch it with itself is changing the conditional, so the conversation will continue on that new condition. 

# Why did i use code to send a message from Nova?
# Everything in multiline code will run at the exact same moment (unless youre doing weird things on purpose with pause and stuff... dont do that...)
# If i didnt use a code block then she would send the message, you would see her active while the code ran, it would then run, and she would 
# Just... become inactive. By running the message send and the update on the conditional at the same time, she sends the message
# goes inactive, no weird delay. 

# The conditional I pass in on line 2 of nova_conditional_messages_2 is just to show that you can link conditions, it will always eval to True

label conditional_messaging:
    "Label for this section is conditional_messaging"
    kesash "So, did you wonder why you can controll the money counter in the top left? It's for this"
    kesash "Make sure its below 500, and then click to the next message"
    $ kps_update_conversation(mc_nova_conversation, nova_conditional_messages, "money > 500")
    kesash "Ive just added a new conversation for Nova, but, it will only progress if you have more than 500 money"
    kesash "If you dont? Cant even message her, conversation completely frozen"
    kesash "Try increasing and decresing your money and you can see it stopping and starting"
    kesash "The entire conversation is a single conversation list, there is no branching here"
    kesash "When I change the conditions I am simply modifying them using the phone itself"
    kesash "Finished that one? Okay, lets go to the next one!"
    kesash "This time the condition will only stop you from starting the conversation, but once its started, you can continue it no matter what"
    $ kps_update_conversation(mc_nova_conversation, nova_conditional_messages_2, "money < 0")
    kesash "Alright, as soon as your money is less than 0 you can start the next one"
    kesash "But even if you go back above, it will still continue"
    kesash "Done?"
    kesash "Next click is back to the menu"
    jump advanced_conversations_menu