﻿

# HELLO! And welcome to the demo for my phone system :)

# To use this system you MUST have phone.rpy and phone_config.rpy.
# There is also a gallery system (gallery_system.rpy) that will create the phone gallery for you. 

# This demo has 4 'test_char' files, they start at 1-3 are creating phone conversation with increasing complexity. 
# 4 has some examples for cool ways you can tie the system into gameplay. 



default money = 0

default sarah_phone_show = False

default mc_phone_show = True

default iris_phone_show = False

define kesash = Character("Kesash", color="#ff0000")

# REMEMBER TO SET TO FALSE AFTER TESTING

define allow_continue = False

image white = Solid("#FFFFFF")


label start:
    # Just setting the default phone, if youre not using the function ALWAYS use deepcopy. 
    $ phone_data = copy.deepcopy(mc_phone)
    # Im just adding a message into the conversation between you and nova, so its there when you open the phone
    $ kps_send_message_to_phone(mc_nova_conversation, "nova", "Hey!")
    call show_all_gui from _call_show_all_gui

    # scene white
    # hide screen say
    # pause

    kesash "HELLO! AND WELCOME TO THE PLAYABLE DEMO FOR MY PHONE SYSTEM!"
    kesash "I made it with the intention of you having the code open for each character as you speak to them, That way you can see exactly how each conversation is coded"
    kesash "There are 5 files that this demo will go through"
    kesash "They all have the same name, test_char_ then 1, 2, 3, 4 or 5"
    kesash "1 to 3 start simple and get more complex, 4 is a demo of the new DSL, and 5 shows how it can be tied into gameplay"
    kesash "If you want to open those files and open the phone, all those conversations are already loaded in, you can go and have them now"
    kesash "Or just keep clicking and ill give you a menu with some options to see what you can do in game"
    kesash "All those conversations will stay available the entire time, you can have them whenever you want"
    kesash "(Except the one with Nova, I will clear that after this message, as I use her for all these examples)"
    kesash "Also, the new 'allow clickthrough' option in the phone settings allows you to go through these chats while also having conversations on the phone"
    kesash "This demo was not made with that being on in mind, everything SHOULD be fine, but just be aware"
    kesash "Ready to move on? Cool, ill show you some cool stuff now then"
    $ mc_nova_conversation['current_dialogue'] = []
    kesash "Everything from having optional conversations you can have at any time, to forcing the phone open and not letting you close it until a conversation is finished"
    kesash "Or even someone getting annoyed at you if you don't reply fast enough"
    kesash "Everything here is done in test_char_5.rpy"
    kesash "Oh, and check the settings on your phone :)"
    jump advanced_conversations_menu








        