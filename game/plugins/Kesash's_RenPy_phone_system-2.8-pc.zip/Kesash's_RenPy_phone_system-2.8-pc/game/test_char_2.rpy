### MC PHONE IS DEFINED IN TEST_CHAR_1

# Sender keys:
# - image, will send the image, just put the filepath
# -- If you want to set the dimentions too you must use this format intead -> {"image": "imagepath.png","scale":[x, y]}
# - video, sends the video, very untested, isnt even listed as a feature, should work?
# - system, sends whatever you place after : as a system message, see examples in demo to know what that looks like
# - code, will pass anything after the : into exec(). Basically, runs whatever you type as code. 
# - delete, will search for an EXACT string match and delete it. When deleting images just use the file path (example below)
# - Any other key will be treated as the person sending the message. If the sender matches the name of the phone you are using, sent message. If it doesnt, received message. 

define iris_starting_dialogue = kps_build_conversation_list("""
iris: Hello!
iris: Everything here is in test_char_2.rpy
iris: Its a little more complex than Novas, but not as complicated as Sarah's
mc: Okay
iris: So lets start with a system message
system: This is a system message
mc: Yep
iris: Then lets delete a message
iris: I will delete this message
iris: and....
delete: I will delete this message
iris: Poof
mc: Yep, its gone
iris: Next, an image
image:iris/iris_image_1.png
iris: That image will have auto unlocked in the gallery on your phone
mc: and if i want to send an image?
iris: Yep, you can, just need to make sure youre adding a sender key or it will always show on the left
{"image": "iris/iris_image_1.png","sender":"mc"}
iris: And you can change the preview dimensions too if you want, default is portrait though
{"image": "testlandscape.png","scale":[308, 180]}
iris: And you need to use the old style of coding these convos to allow the message to take two key, items
mc: Can you delete images?
iris: Yep, ill delete that landscape one now
delete: testlandscape.png
mc:Anything else?
{"iris":"You can quote reply now, but the syntax is slightly more complicated, same as with the landscape image", "reply":"Anything else?"}
{"mc":"oh, thats cool", "reply":"You can quote reply now, but the syntax is slightly more complicated, same as with the landscape image"}
iris: Now, a choice
iris: if youre looking at the code, the first item in each list is what you see
iris: The second is where that option will take you...
["Option 1","iris_choice_1"],["Option 2","iris_choice_2"],["Option 3","iris_choice_3"]
""")

    # A choice is just a list, of lists. The first item in each list is what the player will see, so when the play gets here they will see
    # 'option 1' 'option 2' 'option 3'
    # The second item in the list is which conversation thread we will go to when they click that option, so here:
    # Clicking option 1 will go to thread iris_choice_1
    # Clicking option 2 will go to thread iris_choice_2
    # Clicking option 3 will go to thread iris_choice_3





define iris_choice_1 = kps_build_conversation_list("""
iris:You picked option 1 :)
iris:Now in the more intermediate chat it used inline code blocks passed into an exec() to converge chats
iris:(If you dont get that, dont worry)
iris:So here i'll show you a much simpler option, using a choice
iris:No matter which option you chose, they end with this choice
["Theres only one option", "iris_after_choices"]
""")


# WHAT?! WHY HAS IT CHANGED?!?!?
# Because there are 2 ways to build conversations. kps_build_conversation_list() just takes whatever you are typing and 
# converts in into the format you see below :)
# I'm leaving these like this just so you can see how it works, and have the option to do it like this yourself. 
# You will also need to use this format for some more complex uses. See test_char_3.rpy for examples. 
# The key: item logic stays identicle though. 
# Choices are placed inside another list, so a list of lists [[],[],[]]


define iris_choice_2= [
    {"iris":"You picked option 2 :)"},
    {"iris":"Now in the more intermediate chat it used inline code blocks passed into an exec() to converge chats"},
    {"iris":"(If you dont get that, dont worry)"},
    {"iris":"So here i'll show you a much simpler option, using a choice"},
    {"iris":"No matter which option you chose, they end with this choice"},
    # So this choice is the EXACT same as the on above. That means that both threads will force the player to move back to 'iris_after_choices', which is where these choices are pointing to
    [["Theres only one option", "iris_after_choices"]]
]

define iris_choice_3 = [
    {"iris":"You picked option 3 :)"},
    {"iris":"Now in the more intermediate chat it used inline code blocks passed into an exec() to converge chats"},
    {"iris":"(If you dont get that, dont worry)"},
    {"iris":"So here i'll show you a much simpler option, using a choice"},
    {"iris":"No matter which option you chose, they end with this choice"},
    # And same again here
    [["Theres only one option", "iris_after_choices"]]
]

define iris_after_choices = [
    {"mc":"There was only one option"},
    {"iris":"Yep, and because all 3 of those conversation threads ended with that choice"},
    {"iris":"No matter what you picked initially, they will all return to this thread"},
    {"iris":"The last thing i'll show you is a simple code message use"},
    {"iris":"See the money counter in the top left?"},
    {"mc":"Yea"},
    {"iris":"Lets make you rich"},
    # This is a simple code block. Anything tagged code will... well... run that code, there are littrally no limits to this. There are some more complicated examples passing multi line code in
    # in the test_char_intermediate.rpy, you can check there if interested.
    # The simplist explination is just imagine anything in that value is being placed into a python: block, and then run. So here we are just running 'money += 10' and modifying that value mid conversation. 
    {"code":"money += 10"},
    {"iris":"See, rich?"},
    {"iris":"A code message just allows you to execute code mid conversation"},
    {"iris":"Sarah has some much more complicated examples"},
    {"mc":"Okay!"},
    {"iris":"Well, I think thats enough for the simple tutorial :)"},
    {"iris":"Make sure to chat to Sarah to see how code block can be used better, and things like group chats"},
    # Just another use of a system message :)
    {"system":"User has gone offline"}
]



# This cool function creates the conversation dict for you
# The first thing you pass in is the conversation that will start loaded into the phone
# after that use kps_member() to add members to the conversation. The first item in kps_member() is always the name
# After that just set whichever variables you want to pass in (there are notes in these in test_char_3.rpy.rpy)
# Here i am just passing in disable_messaging as true for iris, that means this conversation will pause
# if you are using her phone (so, like if you stole it in game, she cant message, you have it)

# You only need to do this ONCE for each contact, so this has perminantly created a link between 'mc' and 'iris'
# Any changes to this conversation will modify the actual dict this creates.

default mc_iris_conversation = kps_build_conversation(iris_starting_dialogue, kps_member("mc", profile = "mc/mc_profile.png"), kps_member("iris", disable_messaging = True, profile = "iris/iris_profile.png"))

# The final thing, is if you want to load a new conversation into the phone, not after a choice, you can use the 
# update_current_convo() function. Takes two inputs, which convo to update, and what to update it with.
# So lets say we want to load the conversation I defined below into the phone


default iris_final_example = [
    {"iris":"This convo willbe loaded in"},
    {"mc":"Cool"}
]

# To do this we would just run update_current_convo(mc_iris_conversation, iris_final_example)
# mc_iris_conversation being the conversaion we defined abobe
# and iris_final_example being the name of the conversation we want to load in :)


# You thought the phone would be hard? NOPE. This is it. This is the phone dict.....
# The gallery is exaplined elsewhere, but unless you want other phones to have a seperate gallery... just ignore it... the one for the mc is done automatically. This is just an option
# The name MUST match the name you are using when adding them as a member of a conversation, that how the system knows which contacts to add to the contacts screen (notice that we arent actually adding contacts to the phone? Done automatically.)
# You only need to create this for people whose phones will actually exist in the game, in the new demo (this one) we never actuall get a hold of iris's phone, so this is unnessesary, but putting it here anyway. 
default iris_phone = {
    "gallery": {},
    "name": "iris",
    "background": ["#9a7aff"]
}

# Adding someone mid conversation

# If a conversation only has 1 member it will default everything to 'Unknown'.
# Adding a member then updates in real time with all the correct information :)

define mc_ember_starting_convo = kps_build_conversation_list("""
Ember: Hey
mc: Hey, who is this?
Ember: Its ember
mc: Oh, let me add you
code: kps_add_member_to_convo(mc_ember_conversation, "Ember")
mc: done :)
Ember: Why didn't you already have me added?
mc: BECAUSE, wanted an example of adding someone mid convo
Ember: At the very bottom of test_char_2?
mc: Yep :)
""")



default mc_ember_conversation = kps_build_conversation(mc_ember_starting_convo, kps_member("mc"))