
# NOTE: As we are adding the conversation to the phone, and the conversation list to the conversation, they are defined in the reverse of that order
# It may 'feel' back to front, but thats just the rules with python. So conversation list -> Conversation -> Phone. 

# Defenitions:
# - conversation list: This is what I call the actual messages being sent back and forth. 
# - conversation: I use this term to refer to the connection between phones. A single conversaiton may start on 
#                 one conversation list, then move to another. Imagine it like a contact on your phone, but you are also a contact on their phone.
#                 when you open your phones you both access the same 'conversation'. 
# - phone: Exactly what it says, if the name on the phone matches a name of a member of a conversation then the contact will appear.


# You have multiple options for what is behind the :, check the test_char_2.rpy for examples.
# If the sender key (bit before :) matches the name of the phone youre using (defined below) it will be a sent message
# else it will be a recieved message (image, video, system, delete and code are all custom keys explained in the rpy mentioned above)

# A choice is just lists, first item is what the player sees, second is which conversation list that choice will take them to, sepperate each list with a ,

define nova_conversation = kps_build_conversation_list("""
nova: This is the simplest way to build a conversation
mc: Thats cool
nova: Just check test_char_1.rpy to see how its made
nova: You can open it now and watch how it's done as we talk if you'd like!
mc: :D
nova: Now ill just let you make a simple choice
["Option 1", "nova_conversation_1"],["Option 2", "nova_conversation_2"]
""") 

define nova_conversation_1 = kps_build_conversation_list("""
nova: You picked option 1
nova: Thats all for this chat 
system: User has gone offline
""")

define nova_conversation_2 = kps_build_conversation_list("""
nova: You picked option 2 
nova: Thats all for this chat
system: User has gone offline
""")

# Use the build conversation function to create the actual conversation link. Save it to any variable you want
# This creates the ENTIRE conversation thread, you only need to do this once per contact. Pass in the initial conversation list
# Because we are using nova_conversation as the starting conversation, that is what we are passing in here.

# You do not need to do ANYTHING with this, just define it, the backend does the rest for you
# (You CAN access and mutate this directly. Examples in further .rpy files)

default mc_nova_conversation = kps_build_conversation(
    nova_conversation, 
    kps_member("mc", profile = "mc/mc_profile.png"), 
    kps_member("nova", profile = "mc/mc_profile.png") # Yea.... Nova didnt get a pfp so im using a default one....
)

# Then create a phone. The name you entered as a member for a conversation? If that matches the name of the phone, the convo will appear.

default mc_phone = {
    "gallery": gallery_data,
    "name": "mc",
    "background": ["#0f1115"],
    "theme": None
}

# Open phone with kps_open_phone(mc_phone)

# Thats it, the rest is done for you automatically by the
# backend. 

######################################
####### EXAMPLES TO COPY PASTE #######
######################################

default name_phone = {
    "gallery": {}, # If you are using my gallery system pass in gallery_data, same as above
    "name": "name_here",
    "background": ["#0f1115"]
}


define set_conversation_name_here = kps_build_conversation_list("""
name_of_sender: message
name_of_sender: message
name_of_sender: message
name_of_sender: message
""")

# And one that ends in a choice, you can add as many ',["what the player sees", "the_convo_it_takes_them_to"]' at the end for more choices, or remove one, or 2. 
# Only 1 choice is needed for a valid entry. 

# ALL choices MUST be on the same line. 

define set_conversation_name_here_choice = kps_build_conversation_list("""
name_of_sender: message
name_of_sender: message
name_of_sender: message
name_of_sender: message
["what the player sees", "the_convo_it_takes_them_to"],["what the player sees", "the_convo_it_takes_them_to"],["what the player sees", "the_convo_it_takes_them_to"]
""")

default name_of_conversation_thread_here = kps_build_conversation(
    set_conversation_name_here, 
    kps_member("name_of_member", profile = "path/to_profile_pic.png"), 
    kps_member("name_of_member", profile = "path/to_profile_pic.png")
)


# Create the conversation using kps_build_conversation(), this will take the conversaion list as the first argument, then members of that conversation.
# Add as many members as youd like, if its more than 2 it will become a group chat

default name_of_conversation_thread_here_group = kps_build_conversation(
    set_conversation_name_here, 
    kps_member("name_of_member"), # Profile pics per member not needed in group chats
    kps_member("name_of_member"),
    kps_member("name_of_member"),
    kps_member("name_of_member"),
    group_profile = "path/to_group_pfp.png" # Only needed if its a group chat
)


# This is how you used to HAVE to build conversations, you no lonegr need to do this, but it is still fully supported

#default nova_conversation = [
#    {"nova":"Hey"},
#    {"mc":"Hi"},
#    {"nova":"This is a simple conversation"},
#    {"mc":":D"},
#    {"nova":"Now a simple choice"},
#    [["Option 1","nova_conversation_1"],["Option 2", "nova_conversation_2"]]
#]






